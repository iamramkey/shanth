/********************************************
 Copyright SIGNA AB, STOCKHOLM, SWEDEN
*********************************************/
// var baseUrl="http://192.168.2.10:8080/avprm/rest/";
var baseUrl="http://localhost:8088/stig_ajs/rest/",
	instance = 'Signature';